#include "frame.h"

#define N 401		    // number of filter coefficients
section("L1_data_b") fract coefs[N] = {
#include "bp_fract.dat"
};

fract section("L1_data_a") input[N];
fract output[N];
accum out = 0;
volatile fract outVal;
int i = 0;		

fract konv;
uint16_t *konvi;
uint32_t konvi32;

//--------------------------------------------------------------------------//
// Function:	Process_Data()												//
//																			//
// Description: This function is called from inside the SPORT0 ISR every 	//
//				time a complete audio frame has been received. The new 		//
//				input samples can be found in the variables iChannel0LeftIn,//
//				iChannel0RightIn, iChannel1LeftIn and iChannel1RightIn 		//
//				respectively. The processed	data should be stored in 		//
//				iChannel0LeftOut, iChannel0RightOut, iChannel1LeftOut,		//
//				iChannel1RightOut, iChannel2LeftOut and	iChannel2RightOut	//
//				respectively.												//
//--------------------------------------------------------------------------//
void Process_Data(void)
{
	if (uart_rx_flag)
	{
		uart_rx_flag = false;
		uart_putch(uart_getch());
	}

	iChannel0LeftOut = iChannel0RightIn;

	input[i] = rbits((iChannel0RightIn>>8));
				
	int j;
	int ix;

	ix  = i;
	out = 0;
			
	// Filter loop
	for (j=0;j<N;j++)
	{
		out += input[ix%N]*coefs[j];

		ix++;
	}

	i--;
	
	if (i<0)
	{
		i = N-1;
	}

	iChannel0RightOut = bitsr(out) << 8;
}

