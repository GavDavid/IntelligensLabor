clear

%egy csomagban l�v� adatok sz�ma
datPerPack = 25;

%a rezon�toregy�tthat�k k�ld�s�nek gyakoris�ga mintav�teli id�k�zben kifejezve
resSendInterval = 125;
actReadPos = 1;

%szenzor m�t azonos�t�ja
sensorMoteID = 16+128;
%szinkron�zenet azonos�t�ja
synchMsgID   = 68;
%b�zis�llom�s (gateway) azonos�t�ja
gwyID        = 4;  %Figyelem! Magasabb mintav�teli frekvenci�n az ID MSByte-ja 1-re van �ll�tva

FIDMic = fopen('mic.dat');
micData = fscanf(FIDMic,'%f\n'); %az �sszes adat beolvas�sa
fclose(FIDMic);


%adott t�pus� �zenetek hossza
lengthOfMsg     = ones(1,256)*(length(micData)+1);
lengthOfMsg(sensorMoteID) = 39+2; %szenzor
lengthOfMsg(synchMsgID) = 16;     %szinkron�zenet
lengthOfMsg(gwyID)  = 33;         %gateway
lengthOfMsg(255)  = 8;            %frames

%rezon�torok sz�ma
numOfResonator = 5;


FIDSens    = fopen('sensorData.dat');
moteSensData = fscanf(FIDSens,'%f\n',[lengthOfMsg(sensorMoteID) inf]);  %eredetileg mote1Data
fclose(FIDSens);

FIDGwy  = fopen('gwySamp.dat');
moteGwyData = fscanf(FIDGwy,'%f\n',[lengthOfMsg(gwyID)  inf]);  %eredetileg mote2Data
fclose(FIDGwy);

FIDSyncP = fopen('stmpSync.dat');
syncDat = fscanf(FIDSyncP,'%f\n',[lengthOfMsg(synchMsgID) inf]);
fclose(FIDSyncP);

% **************************************************************************
% **************************************************************************
%
%
%  Szinkroniz�ci�s pontok form�tumkonverzi�ja
%
%
% **************************************************************************
% **************************************************************************

TimeBase1    = 1/8e6;  % uC �rajel�nek peri�dusideje a szenzoron
TimeBaseDiv1 = 4444;   % mintav�telez�s oszt�sz�ma a szenzoron
sampleTime1  = TimeBaseDiv1*TimeBase1; %mintav�teli id�k�z a szenzoron

TimeBase2    = 1/8e6;   % uC �rajel�nek peri�dusideje a b�zis�llom�son
if (length(moteGwyData)>0)   %id�b�lyeg
    if (moteGwyData(2,1)>0)  % mintav�telez�s oszt�sz�ma a b�zis�llom�son
        TimeBaseDiv2 = 4395;
    else
        TimeBaseDiv2 = 4444;
    end

sampleTime2   = TimeBaseDiv2*TimeBase2;  %mintav�teli id�k�z a b�zis�llom�son
sampleTimeGwy = sampleTime2;


if (length(syncDat)>0)   %van-e szinkroniz�ci�s pont

% lok�lis id� a szenzoron
synchPoints1R = 256.^([0:4-1])*syncDat(5:5+4-1,:);  %szinkroniz�ci�s pontok kialak�t�sa: eg�sz sz�m� kvantum mintav�teli id�k�zben kifejezve
synchPoints1F = 256.^([0:2-1])*syncDat(9:9+2-1,:);  %mintav�teli id�k�z t�rtr�sze
synchPoints1  = synchPoints1R*sampleTime1 + synchPoints1F*TimeBase1; %val�s szinkroniz�ci�s pont

% lok�lis id� a b�zis�llom�son
synchPoints2R = 256.^([0:4-1])*syncDat(11:11+4-1,:);  %szinkroniz�ci�s pontok kialak�t�sa: eg�sz sz�m� kvantum mintav�teli id�k�zben kifejezve
synchPoints2F = 256.^([0:2-1])*syncDat(15:15+2-1,:);  %mintav�teli id�k�z t�rtr�sze
synchPoints2  = synchPoints2R*sampleTime2 + synchPoints2F*TimeBase2; %val�s szinkroniz�ci�s pont

%fileform�tum:
% lok�lis id� a b�zis�llom�son_1    lok�lis id� a szenzoron_1
% lok�lis id� a b�zis�llom�son_2    lok�lis id� a szenzoron_2
% lok�lis id� a b�zis�llom�son_3    lok�lis id� a szenzoron_3
FIDSyncP = fopen('pre_stmpSync.dat','w');
fprintf(FIDSyncP,'%1.9f %1.9f\n', [synchPoints2.' synchPoints1.'].');
fclose(FIDSyncP);

end %if (length(syncDat)>0)   %van-e szinkroniz�ci�s pont

else
    TimeBaseDiv2 = 4444;
end  %if (length(moteGwyData)>0)   %id�b�lyeg


% **************************************************************************
% **************************************************************************
%
% B�zis�llom�s �zeneteinek form�tum konverzi�ja
%
% **************************************************************************
% **************************************************************************

% samples
if (length(moteGwyData)>0)   %van-e adat a gateway-t�l
    
gwySamples = moteGwyData(9:9+datPerPack-1,:);  %data in byte positions [9-33] are the samples
gwySamplesFull = gwySamples(:);

%time stamps
moteGwyTimeStamps = 256.^([0:4-1])*moteGwyData(5:5+4-1,:)*sampleTimeGwy;  %data in byte positions [5-8] are the time stamp of the packet
moteGwyTimeStampsFull = repmat(moteGwyTimeStamps,datPerPack,1);
moteGwyTimeStampsFull = (moteGwyTimeStampsFull + [0:datPerPack-1]'*ones(1,length(moteGwyTimeStampsFull))*sampleTimeGwy);
moteGwyTimeStampsFull = moteGwyTimeStampsFull(:);

%msg sequence numbers
msgSeq = 256.^([0:2-1])*moteGwyData(3:3+2-1,:);

FIDGwyP = fopen('pre_gwySamp.dat','w');
fprintf(FIDGwyP,'%d %1.9f %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d %3.3d \r\n', [msgSeq.' moteGwyTimeStamps.'  gwySamples.'].');
%                       0  1           5             10             15             20             25  
fclose(FIDGwyP);


FIDSensP = fopen('pre_gwySampFull.dat','w');
fprintf(FIDSensP,'%1.9f %3.3d \r\n', [moteGwyTimeStampsFull(:)  gwySamplesFull].');
fclose(FIDSensP);

%form�tum:
% Msg_ID_1   t1=TimeStamp_1  phase(t1)  rez1Re(t1) rez1Im(t1) rez2Re(t1) rez2Im(t1) ... rez5Re(t1) rez5Im(t1)  1-5/odd
% Msg_ID_2   t2=TimeStamp_2  phase(t2)  rez1Re(t2) rez1Im(t2) rez2Re(t2) rez2Im(t2) ... rez5Re(t2) rez5Im(t2)  1-5/odd
% Msg_ID_3   t3=TimeStamp_3  phase(t3)  rez1Re(t3) rez1Im(t3) rez2Re(t3) rez2Im(t3) ... rez5Re(t3) rez5Im(t3)  1-5/odd
%  .
%  .
%  .
end  %if (length(moteGwyData)>0)   %id�b�lyeg

% **************************************************************************
% **************************************************************************
%
% A szenzor �zeneteinek form�tum konverzi�ja (Fourier egy�tthat�k t�rol�sa)
%
% **************************************************************************
% **************************************************************************


% struct MicOlvMsg
%  {
%   uint16_t forrasMoteID;            //bytes: 1, 2
%   uint16_t csomagSzam;              //bytes: 3, 4
%   uint32_t ui32SampleTimeStamp;     //bytes: 5, 6, 7, 8
%   uint8_t  adat[BUFFER_SIZE];       //bytes: 9, 10 ... 33
%   uint32_t ui32LocTick;             //bytes: 34, 35, 36, 37  -- k�ld�s id�pontja: durva felbont�s
%   uint16_t ui16FineTimeStamp;       //bytes: 38, 39          -- k�ld�s id�pontja: finom felbont�s
%   uint16_t phaseAtSend;             //bytes: 40, 41   // format : 0ppp_ppp__pppp_ppp0  : els� �s utols� bit nulla
%  };
% a 31-edik byte jelzi, hogy az els� 5 vagy a p�ratlan harmonikusokat
% sz�m�tja
%  31. bit: 
%        0: res: 1...5;;;  
%        1: odd: 1,3,5,7,9

numOfResonator = 5;

%az eg�sz mintav�teli id�pontban olvassa ki a f�zist, �gy el�g az eg�sz
%mintav�teli id�pontot felhaszn�lni id�b�lyegk�nt
%------------------S------|-----------S------------------S------------------S
%                         |
%               phase     |
%               send      send time fine
%
moteSensPhaseAtSend  = 256.^([0:2-1])*moteSensData(40:40+2-1,:) / 2^15 * 2*pi; %a f�zis �rt�ke a k�ld�s idej�ben
moteSensResSendTime = 256.^([0:4-1])*moteSensData(34:34+4-1,:)*sampleTime1;  %a v�ltoz�k k�ld�s�nek id�pontja

moteSensResModeOdd   = all(moteSensData(31,:)>0); 

%�zenet sorsz�m
msgSeq = 256.^([0:2-1])*moteSensData(3:3+2-1,:);

%a rezon�torok �rt�keinek a [9...(9+25-1)] byteok vannak fenntartva
%ebb�l az els� 2 byte nem hasznos
%az ezt k�vet� 2*2*5=20 byte a k�vetkez� form�tum�:
%x_1_real_low x_1_real_high x_1_imag_low x_1_imag_high ... x_k_real_low x_k_real_high x_k_imag_low x_k_imag_high
%A t�bbi byte nem hasznos
moteSensResonator   = moteSensData(9:9+datPerPack-1,:); 
moteSensResonator   = moteSensResonator(3:end,:);  %DC rezon�tor elt�vol�t�sa
moteSensResonator   = moteSensResonator(1: 2*2*numOfResonator,:);  %azon komponensek elt�vol�t�sa, melyek nem tartalmaznak hasznos adatot
moteSensResonator(2:2:end,:) = (moteSensResonator(2:2:end,:)>=128)*(-256)+moteSensResonator(2:2:end,:); %�talak�t�s kettes komplemens k�db�l
resConversionMx  = []; 
for resSel=1:2*numOfResonator resConversionMx = blkdiag(resConversionMx,256.^([0:2-1]));end
%resConversionMx=
%|1 256 0  0  0  0  0   0   0   0  |
%|0  0  1 256 0  0  0   0   0   0  |
%|0  0  0  0  1 256 0   0   0   0  |
%|0  0  0  0  0  0  1  256  0   0  |
%|0  0  0  0  0  0  0   0   1  256 |
%
% A m�trix megfelel� s�lyoz�ssal "�sszeadja" az LSB �s MSB byte-okat �s meghagyja a sorokat
moteSensResonator   = resConversionMx*moteSensResonator;
moteSensResonator   = j *moteSensResonator(1:2:end,:) +  moteSensResonator(2:2:end,:);
moteSensResonator   = moteSensResonator.'/16/2;

numForm = '%+3.5f ';
fileFormatStr = ['%d %1.9f %1.6f     ' repmat(numForm,1,5) '   ' repmat(numForm,1,5) '%d' '\r\n'];
FIDSensP = fopen('pre_sensorResonator.dat','w');
fprintf(FIDSensP,fileFormatStr, [msgSeq.' moteSensResSendTime.' moteSensPhaseAtSend.' real(moteSensResonator)  imag(moteSensResonator) ones(size(msgSeq.'))*moteSensResModeOdd ].');  %moteSensResModeOdd.'
%fprintf(FIDSensP,'%f',20);
fclose(FIDSensP);

disp(['Az elofeldolgozas befejezodott.'])

%plot3(moteSensResSendTime,real(moteSensResonator),  imag(moteSensResonator) )

%form�tum:
% Msg_ID_1   t1=TimeStamp_1  phase(t1)  rez1Re(t1) rez1Im(t1) rez2Re(t1) rez2Im(t1) ... rez5Re(t1) rez5Im(t1)  1-5/odd
% Msg_ID_2   t2=TimeStamp_2  phase(t2)  rez1Re(t2) rez1Im(t2) rez2Re(t2) rez2Im(t2) ... rez5Re(t2) rez5Im(t2)  1-5/odd
% Msg_ID_3   t3=TimeStamp_3  phase(t3)  rez1Re(t3) rez1Im(t3) rez2Re(t3) rez2Im(t3) ... rez5Re(t3) rez5Im(t3)  1-5/odd
%  .
%  .
%  .

%form�tum:
% Msg_ID_1   t1=TimeStamp_1  phase(t1)  rez1Re(t1) rez2Re(t1) ... rez5Re(t1) rez1Im(t1) rez2Im(t1) ... rez5Im(t1)  1-5/odd
% Msg_ID_2   t2=TimeStamp_2  phase(t2)  rez1Re(t2) rez2Re(t2) ... rez5Re(t2) rez1Im(t2) rez2Im(t2) ... rez5Im(t2)  1-5/odd
% Msg_ID_3   t3=TimeStamp_3  phase(t3)  rez1Re(t3) rez2Re(t3) ... rez5Re(t3) rez1Im(t3) rez2Im(t3) ... rez5Im(t3)  1-5/odd
%  .
%  .
%  .





















