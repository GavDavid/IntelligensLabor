[x,fsx] = audioread('ventillator_230V.wav');
spectrogram(x(:,1),fsx)
%[y,fsy] = audioread('ventillator_230V_11025sample_s.wav');

%[y,fsy] = audioread('ventillator_dinamic.wav');
%[y,fsy] = audioread('ventillator_dynamic_stepdown.wav');
%[y,fsy] = audioread('ventillator_dynamic_stepup.wav');
[y,fsy] = audioread('ventillator_stepup2.wav');
[y,fsy] = audioread('ventillator_peaktopeak.wav');
%s = spectrogram(y(:,1),fsy,round(fsy*0.75),fsy, fsy)
t = 1:size(y);
plot(y(:,1),t)
