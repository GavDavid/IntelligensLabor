/*
** ADI initialize header file.
**
** Copyright (C) 2000-2012 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically
*/

#ifndef __ADI_COMPONENT_INIT_H__
#define __ADI_COMPONENT_INIT_H__
#include <stdint.h>

#ifdef __HAS_SEC__
#include <services/int/adi_sec.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Declare "adi_initComponents()" */
int32_t adi_initComponents(void);

#ifdef __cplusplus
}
#endif

#endif /* __ADI_COMPONENT_INIT_H__ */
